# ARK Fichas Online

Projeto pronto para subir em um repositório no GitHub e publicar com GitHub Pages.

## Estrutura

- `index.html` → tela inicial com login Google
- `pages/ficha.html` → ficha principal
- `pages/admin.html` → painel do mestre
- `assets/css/` → estilos separados
- `assets/js/` → scripts separados
- `config/firestore.rules` → regras iniciais do Firestore

## Antes de subir

Você precisa trocar **SEU_EMAIL_GOOGLE_AQUI** em dois arquivos:

1. `assets/js/firebase-config.js`
2. `config/firestore.rules`

Sem isso, o painel do mestre não fica liberado para ninguém.

## Como publicar no GitHub

1. Crie um repositório vazio.
2. Envie todo o conteúdo desta pasta para a raiz do repositório.
3. No GitHub, vá em **Settings > Pages**.
4. Escolha a branch principal e a pasta `/root`.
5. Salve.

## Como configurar o Firebase

1. No Firebase Authentication, ative **Google**.
2. Em **Authorized domains**, adicione seu domínio do GitHub Pages, por exemplo:
   `SEUUSUARIO.github.io`
3. No Firestore, cole as regras de `config/firestore.rules`.

## Observações importantes

- O sistema salva a ficha principal de cada usuário em `workspaces/{uid}`.
- Cada usuário mantém suas abas da ficha dentro do próprio workspace.
- O mestre pode abrir e editar qualquer workspace pelo painel.
- O salvamento em nuvem acontece automaticamente com pequeno atraso.
- O salvamento local no navegador continua existindo como apoio.